# 
# HP Insight Manager Agent 8.1.0 Installer
# 

#
# *********************************************************************
# ** Global Variables that need to be modified with each release     **
# *********************************************************************
HPASM_PACKAGE="hpasm-8.1.0-121.vmware30.i386.rpm"
HPRSM_PACKAGE="hprsm-8.1.0-118.vmware30.i386.rpm"
HPSMH_PACKAGE="hpsmh-2.1.12-200.vmware.i386.rpm"
HP_OPENIPMI_PACKAGE="hp-OpenIPMI-8.1.0-118.vmware30.i386.rpm"

HPASM_PACKAGE_MD5=a599cf95af028341d06f2007a2dfed35
HPRSM_PACKAGE_MD5=db15ecf754f6047df29679e19bd1e2ab
HPSMH_PACKAGE_MD5=a969f2d4d100c1d92a2b06df9f3c52d2
HP_OPENIPMI_PACKAGE_MD5=73edbc0ef15eacfffddf4b5b21c72dca

SUPPORTED_VERSIONS="3.0.1 3.0.2 3.0.3 3.5.0"
BUILD_NUMBER="24"
VERSION_NAME=8.1.0

# *********************************************************************
# initialize failed counter and failed list to be empty
# *********************************************************************
cAGENT_FAILED=0
AGENT_BADLIST=""

# *********************************************************************
# Used to decide whether the ESX is running Pegasus within HP device
# *********************************************************************
FOUND_IPMI=0
isPegasusStop=0
isPegasusSysStatus=0

#
# Flag to enable checking for Pegasus
# Initialize to enable Pegasus Check for now
#
#
fEnablePegasusCheck=1



# *********************************************************************
# The name of the log file
# *********************************************************************
LOGFILENAME="hpmgmtlog"

if [ ! -n "$VERSION_NAME" ] ; then
	VERSION_NAME="8.0.0"
fi

if [ -n "$BUILD_NUMBER" ] 
then
	MINOR_VERSION="-$BUILD_NUMBER"
else
	MINOR_VERSION=""
fi
# Identify the ESX Version where agents are to be installed

ESX_BUILD_VERSION=`vmware -v | cut -d"-" -f2`

INSTALLATION_VERSION=`vmware -v`
INSTALLED_VERSION=`vmware -v | awk '{print $4}'`
if [ -z $INSTALLED_VERSION ]
then
	$SETCOLOR_RED
	echo "ERROR:ESX OS Version:null"
	$SETCOLOR_NORMAL
fi

SMH_PKGLIST="HPSMH_PACKAGE"

#Only include hprsm if iLO/RILOE/RILOE2 is found
cut -f2 /proc/bus/pci/devices | grep -i "0e11b203\|80861960\|0e11005a" > /dev/null 2>&1
if [ $? -eq 0 ]; then
# Commenting this as 8.0 cmanic agents are not available
        AGENT_PKGLIST="HPASM_PACKAGE HPRSM_PACKAGE"
else
        AGENT_PKGLIST="HPASM_PACKAGE"
fi

# Check whether the system is having Embedded Health Management Controller
cut -f2 /proc/bus/pci/devices | grep -i "103c3302" > /dev/null 2>&1
if [ $? -eq 0 ]; then
        FOUND_IPMI=1
fi

# On Systems with Embedded Health Management Controller install hp-OpenIPMI rpm
# version of enhancement and fixed
if [ $FOUND_IPMI -ne 0 ] ; then
	AGENT_PKGLIST="HP_OPENIPMI_PACKAGE $AGENT_PKGLIST"
fi


AGENTLIST="cmanic cmastor hprsm hpasm hp-OpenIPMI"
SMHLIST="hpsmh"
#Agent services
AGENTSERVICES="cmanic cmastor hprsm hpasm"

# Search pattern for checking installed agents
SEARCH_AGENTS="hpsmh\|cmanic\|hprsm\|hpasm\|hp-OpenIPMI"

ASMSVC=hpasm
SMHSVC=hpsmhd
SNMPSVC=snmpd
SMHPKG=hpsmh
HPIPMIPKG=hp-OpenIPMI


. /etc/init.d/functions

# Set the positon  to print OK/FAILED
RES_COL=74
MOVE_TO_COL="echo -en \\033[${RES_COL}G"

SETCOLOR_BLUE="echo -en \\033[1;34m"
SETCOLOR_WHITE="echo -en \\033[0;39m"
SETCOLOR_RED="echo -en \\033[0;31m"
SETCOLOR_CYAN="echo -en \\033[0;36m"
SETCOLOR_MAGENTA="echo -en \\033[1;31m"
SETCOLOR_LIGHTRED="echo -en \\033[1;31m"
SETCOLOR_YELLOW="echo -en \\033[1;33m"

SETCOLOR_WARNING=$SETCOLOR_YELLOW
SETCOLOR_FAILURE=$SETCOLOR_RED


setsuccess() { 
[[ ! $SILENT ]] && echo `echo_success` || echo "....OK"
echo -e "\t[ OK ]" >> $LOGFILENAME

}
setfailure() {
[[ ! $SILENT ]] && echo `echo_failure` || echo "....FAILED"
echo -e "\t[ FAILED ]" >> $LOGFILENAME
}

splash() {
	echo " "
	if [[ ! $SILENT ]]; then $SETCOLOR_BLUE; fi
	echo "HP Insight Manager Agent ${VERSION_NAME}${MINOR_VERSION} Installer for VMware ESX Server"
        echo " Target System is $INSTALLATION_VERSION "
	if [[ ! $SILENT ]]; then $SETCOLOR_NORMAL; fi
	echo -e "HP Insight Manager Agent ${VERSION_NAME}${MINOR_VERSION} Installer for VMware ESX Server" >> $LOGFILENAME
        echo " Target System is $INSTALLATION_VERSION " >> $LOGFILENAME
	echo " "
}

error() {
	$SETCOLOR_LIGHTRED	
	echo $1 | tee -a $LOGFILENAME
	echo -e "Check $LOGFILENAME for additional information"
	$SETCOLOR_NORMAL
}

log() {
	echo $1 >> $LOGFILENAME
}


#version of enhancement and fixed
do_exit() {

	echo "Exit $1" >> $LOGFILENAME
	Start_Pegasus
	exit $1
}


determine_pegasus_check() {

#
# determine the number of IPMI handles that are being used
# NOTE: If the number of IPMI handles that is being used in non-zero,
#       we make the assumption that we will need to check for Pegasus
#       and manipulate it accordingly
#

   declare LINE

   lsmod | grep ipmi > ipmi_info.txt

   exec 3< ipmi_info.txt
   read LINE <&3

   echo $LINE > first_line.txt

   num_of_handles=`cut -d" " -f3 < first_line.txt`
   device_name=`cut -d" " -f1 < first_line.txt`

   echo determine_pegasus_check >> $LOGFILENAME
   echo [ device: $device_name handles: $num_of_handles ] >>  $LOGFILENAME
   echo >> $LOGFILENAME

   if [ "$device_name" = "ipmi_devintf" -o "$device_name" = "ipmi_si_drv" ]; then 
      if [ $num_of_handles -ne 0 ]; then
         fEnablePegasusCheck=$num_of_handles 
      fi
   fi
   echo Enable Pegasus Check value [ $fEnablePegasusCheck ] >> $LOGFILENAME
   echo >> $LOGFILENAME

   #
   # clean up. delete the temporary files created
   # 

   rm -f ipmi_info.txt
   rm -f first_line.txt
}


verify_action() {
	echo "" | tee -a $LOGFILENAME
	echo "This script will now attempt to $1 the HP Insight Manager Agents. " | tee -a $LOGFILENAME
	echo -n "Do you wish to continue (y/n) " | tee -a $LOGFILENAME
	read answer
	echo "$answer" >> $LOGFILENAME
	if [ "$answer" != "y" ]; then
		error "Action cancelled by user"
		do_exit 34
	fi
}

verify_root() {
	if [ $UID != 0 ]; then
		error "You must be logged on as 'root' to continue"
		do_exit 30
	fi
}
remove_from_list() {
	AGENT_PKGLIST=`echo $AGENT_PKGLIST | sed "s/$1//"`		
	SMH_PKGLIST=`echo $SMH_PKGLIST | sed "s/$1//"`		
}
verify_pkgs() {
	echo "Verifying RPM packages:" | tee -a $LOGFILENAME
	for i in ${AGENT_PKGLIST} ${SMH_PKGLIST}; do
		echo -ne "\tVerifying ${!i}" | tee -a $LOGFILENAME
		if [ ! -f ${!i} ]
		then
			setfailure
			$SETCOLOR_LIGHTRED
			echo -e "Package ${!i} is missing" | tee -a $LOGFILENAME		
			$SETCOLOR_NORMAL
			do_exit 4 
			
		else
			PKGMD5=${i}_MD5
			if [ "${!PKGMD5}" = `md5sum ${!i} | awk '{print $1}'` ]; then
				setsuccess
			else
			
				setfailure
				$SETCOLOR_LIGHTRED
				echo -e "Package ${!i} is corrupted" | tee -a $LOGFILENAME
 				$SETCOLOR_NORMAL
				do_exit 4
			fi
	 	fi
	done
}

# Function that checks dependency 
check_dependency() {
	echo -en "\tChecking dependencies of $1" | tee -a $LOGFILENAME
	local PACKAGE_NAME=`rpm -qp --queryformat '%{NAME}' $1 2> /dev/null`
	`rpm -ivh --test $1 > /dev/null 2>&1`
	if [ $? -eq 0 ]
	then
		setsuccess
		return 0
	else
		local installed_version=`rpm -q $PACKAGE_NAME|sed -e '/is not installed/d'`
		if [ -n "$installed_version" ] && ( echo $1 | grep -q $installed_version )
 		then
			setsuccess
			return 0
		else
			setfailure
			if ( rpm -ivh --test $1 2>&1 | grep -qF "failed dependencies" ) 
			then
				$SETCOLOR_LIGHTRED	
				echo -e "Package has dependencies."
				$SETCOLOR_NORMAL
			fi
			if ( rpm -ivh --test --nodeps $1 2>&1 | grep -qF "conflicts" ) 
			then
				$SETCOLOR_LIGHTRED	
				echo -e "This package conflicts with an installed package."
				$SETCOLOR_NORMAL
			fi
				
			$SETCOLOR_LIGHTRED	
			echo -e "Check $LOGFILENAME for additional information"
			$SETCOLOR_NORMAL
			rpm -iv --test $1 > /dev/null 2>> $LOGFILENAME
			rpm -iv --test --nodeps $1 > /dev/null 2>> $LOGFILENAME
			echo -e "" >> $LOGFILENAME
			return 1
		fi
	fi
}

verify_esx_version() {
	echo -n "Verifying VMware ESX Server version" | tee -a $LOGFILENAME
		
	if [ ! -f /usr/bin/vmware ] 
	then
		setfailure
                error "Installation can be done in VMware ESX Server only!" | tee -a $LOGFILENAME
		echo "Exiting..." >> $LOGFILENAME
                do_exit 31
	fi
	if [ -n "$INSTALLED_VERSION" ] && ( echo $SUPPORTED_VERSIONS | grep -qF "$INSTALLED_VERSION" ) 
	then
		setsuccess
	else
		setfailure
		error "Installer does not support the VMware ESX Server version" | tee -a $LOGFILENAME
		echo "Exiting..." >> $LOGFILENAME
		do_exit 31
	fi
}

check_installed() {
	INSTALLEDPKGS=`rpm -q $@ | sed -e '/not installed/d'`
}

stop_agents() {
	local TMP
	echo -n "Stopping HP Insight Manager agents:" | tee -a $LOGFILENAME
	for i in $AGENTSERVICES; do
		rpm -qa | grep ${i} > /dev/null 2>> $LOGFILENAME
		if [ $? -eq 0 ]; then
			if [ -z $TMP ]; then TMP=1;echo "" | tee -a $LOGFILENAME;fi
			svc_control "\tStopping ${i}" stop $i
		fi
	done
	[ -z $TMP ] && setsuccess
}

stop_snmp() {
	local TMP
        echo -ne "Stopping SNMP stack:" | tee -a $LOGFILENAME
	pidof snmpd > /dev/null 2>> $LOGFILENAME
	if [ $? -eq 0 ]; then
		echo "" | tee -a $LOGFILENAME
		svc_control "\tStopping snmpd" stop $SNMPSVC
		TMP=1
	fi
	[ -z $TMP ] && setsuccess
}

stop_smh() {
	check_installed hpsmh
        [[ $INSTALLEDPKGS ]] && svc_control "Stopping System Management Homepage" stop $SMHSVC
	# Make sure SMH is really stopped and all files are cleaned up
	# Wait for up to 30 sec for SMH to stop gracefully
	unset STOPPED
	for i in `seq 1 6`; do 
		echo "Waiting for SMH to stop" >> $LOGFILENAME
		if [ -f /opt/hp/hpsmh/logs/httpd.pid ]; then
			echo "SMH not stopped yet...sleeping for 5" >> $LOGFILENAME
			sleep 5
		else	
			STOPPED=1
			echo "SMH is now stopped" >> $LOGFILENAME
			break
		fi
	done
	# Are we still not stopped?
	if [[ ! $STOPPED ]]; then  
		echo "Forcing shutdown of SMH" >> $LOGFILENAME
		[ -f /opt/hp/hpsmh/logs/httpd.pid ] && rm -f /opt/hp/hpsmh/logs/httpd.pid
		killall -9 hpsmhd >> $LOGFILENAME 2>&1
	fi
	[ -f /var/lock/subsys/hpsmhd ] && rm -f /var/lock/subsys/hpsmhd
}

start_snmp() {
        echo "Starting SNMP stack:" | tee -a $LOGFILENAME
	svc_control "\tStarting snmpd" start $SNMPSVC
}

remove_packages() {
	echo -n "$1:" | tee -a $LOGFILENAME
	shift
	check_installed $@
	if [ -z "$INSTALLEDPKGS" ]; then
		setsuccess
	else
		echo " " | tee -a $LOGFILENAME
		for i in $INSTALLEDPKGS; do
			echo -ne "\tRemoving ${i}: " | tee -a $LOGFILENAME
                	rpm -e --nodeps ${i} >> $LOGFILENAME 2>&1
                	if [ $? -eq 0 ]; then
                	        setsuccess
                	else
                	        setfailure
                	        error "Unable to remove ${i}"
                	        
							cAGENT_FAILED=$(( $cAGENT_FAILED + 1 ))
							AGENT_BADLIST="${i} $AGENT_BADLIST"
                	fi
                done
        fi
}


#Function that installs packages
install_packages() {
 
	local PACKAGE_NAME
	echo "$1:" | tee -a $LOGFILENAME
	shift
	for i in $@; do
#
#		check whether this is a src rpm . If it is then install it.	
#
		if ( echo ${!i} | grep -q "src.rpm" ) ; then
			echo -ne "\tInstalling ${!i}" | tee -a $LOGFILENAME
                        echo "" >> $LOGFILENAME
                        rpm -ivh ${!i} >> $LOGFILENAME 2>&1
                        if [ $? -eq 0 ]; then
                                setsuccess
                        else
                                setfailure
                        fi
                        echo "" >> $LOGFILENAME
		else
#
#	 		Find out the Package name 
#
			PACKAGE_NAME=`rpm -qp --queryformat '%{NAME}' ${!i} 2> /dev/null`
			check_dependency ${!i}
			if [ $? -eq 0 ] 
			then
				echo -ne "\tInstalling ${!i}" | tee -a $LOGFILENAME
				echo "" >> $LOGFILENAME
       				rpm -ivh ${!i} >> $LOGFILENAME 2>&1
				if [ $? -eq 0 ]; then
   	                	setsuccess
        	        else
       	        		setfailure
                        cAGENT_FAILED=$(( $cAGENT_FAILED + 1 ))
						AGENT_BADLIST="${!i} $AGENT_BADLIST"
				fi
				echo "" >> $LOGFILENAME
				
			elif [ ! $SILENT ]
			then
				echo -en "Do you want to force the installation of the package ${!i} <y/n> ? (Blank is n) " | tee -a $LOGFILENAME
				read choice 
				echo  "$choice" >> $LOGFILENAME
				if [ "$choice" = "y" ]
				then
			     		echo -ne "\tInstalling ${!i}" | tee -a $LOGFILENAME
					echo "" >> $LOGFILENAME
 		                        rpm -ivh --force --nodeps ${!i} >> $LOGFILENAME 2>&1
               				if [ $? -eq 0 ]; then
	   			               	setsuccess
	               			else
		        	            setfailure
                        		cAGENT_FAILED=$(( $cAGENT_FAILED + 1 ))
								AGENT_BADLIST="${!i} $AGENT_BADLIST"
								echo "" | tee -a $LOGFILENAME
								echo "The HP Insight Manager Agents, ${!i} is not installed on the system. " | tee -a $LOGFILENAME					 
							fi
				fi
				echo "" >> $LOGFILENAME
				else
					$SETCOLOR_LIGHTRED
					echo "${!i} can't be installed" | tee -a $LOGFILENAME
					$SETCOLOR_NORMAL
					echo "" >> $LOGFILENAME
                    cAGENT_FAILED=$(( $cAGENT_FAILED + 1 ))
					AGENT_BADLIST="${!i} $AGENT_BADLIST"
			fi
		fi
	done
	
}

configure_hpasm() {
	
	echo -n "HP Advanced Server Management configuration:" | tee -a $LOGFILENAME
	if [ ! -f /opt/compaq/hpasm/etc/hpasm ]
	then
		setfailure
		echo "/opt/compaq/hpasm/etc/hpasm: No such file or directory" >> $LOGFILENAME
		error "HP Advanced Server Management configuration failed"
		return 99
	fi
	if [ ! -e /sbin/hpasm ]
	then
        	echo -en "\nDo you want to reconfigure hpasm <y/n> ? (Blank is n) " | tee -a $LOGFILENAME
		read choice
                echo  "$choice" >> $LOGFILENAME
                if [ "$choice" = "y" ]
                then
			/opt/compaq/hpasm/etc/hpasm reconfigure
			if [ $? -eq 0 ]; then
				setsuccess
			else
				setfailure
				error "HP Advanced Server Management configuration failed"
				return 99
			fi
		fi
	else		
		/opt/compaq/hpasm/etc/hpasm activate
		if [ $? -eq 0 ]; then
			setsuccess
		else
			setfailure
			error "HP Advanced Server Management configuration failed"
			return 99
		fi
	fi
}

configure_hpsmh() {

	if [ -e ./smhpd.xml ]; then
		log "Found SMH configuration file...copying"
		echo -n "Copying SMH configuration"
		cp ./smhpd.xml /opt/hp/hpsmh/conf/smhpd.xml
		if [ $? -eq 0 ]; then
			SMHAUTOCONF=1
			setsuccess
		else
			setfailure
			error "HP System Management Homepage configuration failed"
		fi
	else
		echo "SMH Configuration file not found...no action taken" >> $LOGFILENAME
	fi
}

svc_control() {
	echo -ne "$1:" | tee -a $LOGFILENAME
	service $3 $2 > /dev/null 2>> $LOGFILENAME
        if [ $? -eq 0 ]; then
		setsuccess
		return 0
	else
		setfailure
		error "Unable to ${2} ${3}"
	fi

}

post_splash() {
	case "$1" in
	
	install)
	
	if [[ -z $SMHAUTOCONF ]]; then
		echo "**********************************************************" | tee -a $LOGFILENAME 
		echo "* System Management Homepage installed successfully with *" | tee -a $LOGFILENAME
		echo "* default configuration values.   To change the default  *" | tee -a $LOGFILENAME
		echo "* configuration values,  type the following command at   *" | tee -a $LOGFILENAME
		echo "* the root prompt:                                       *" | tee -a $LOGFILENAME
		echo "*                                                        *" | tee -a $LOGFILENAME
		echo "* perl /usr/local/hp/hpSMHSetup.pl                       *" | tee -a $LOGFILENAME
		echo "*                                                        *" | tee -a $LOGFILENAME
		echo "**********************************************************" | tee -a $LOGFILENAME
	fi
	echo "Please read the License Agreement for this software at"  | tee -a $LOGFILENAME
	echo "" | tee -a $LOGFILENAME
	echo "/opt/compaq/hpasm/hpasm.license" | tee -a $LOGFILENAME
	echo " " | tee -a $LOGFILENAME
	echo "By not removing this package, you are accepting the terms" | tee -a $LOGFILENAME
	echo -e "of the \"License for HP Value Added Software\"." | tee -a $LOGFILENAME
	;;
	esac

	echo "" | tee -a $LOGFILENAME

	if [ $cAGENT_FAILED -ne 0 ]
	then

		$SETCOLOR_FAILURE
		echo "The following HP Insight Manager agent(s) FAILED to $1 on the system:" | tee -a $LOGFILENAME		
        for i in $AGENT_BADLIST; do 
			echo $i | tee -a $LOGFILENAME
	 	done	
		$SETCOLOR_NORMAL

	else

		echo "HP Insight Manager agents have been ${1}ed successfully!" | tee -a $LOGFILENAME
	fi
	echo "" | tee -a $LOGFILENAME

    do_exit
}

check_installed_pkgs() {
        INSTALLEDAGENTS=`rpm -qa | grep "$SEARCH_AGENTS"`
        echo -n "Checking for previously installed agents" | tee -a $LOGFILENAME
        if [ -z "$INSTALLEDAGENTS" ]; then
                setsuccess
        else
                setfailure 
		echo " The following packages have already been installed on your system:" >> $LOGFILENAME
        	rpm -qa | grep "$SEARCH_AGENTS" >> $LOGFILENAME
		echo "Please remove the previous installation" >> $LOGFILENAME
		$SETCOLOR_LIGHTRED	
                echo "Some agents have already been installed. Please remove the previous installation."
		echo -e "Check $LOGFILENAME for additional information"
		$SETCOLOR_NORMAL
		do_exit 1
        fi
}

### enhancement and fixed
verify_PegasusStatus() {

	if [ $fEnablePegasusCheck -eq 0 ]
	then
		isPegasusSysStatus=0
		return
	fi

	checkPegasus=`service pegasus status | cut -d" " -f3`
		
	if [ "$checkPegasus" != "stopped" ]; then
		## if Pegasus is on, $isPegasusSysStatus is 1
		isPegasusSysStatus=1
		echo "Pegasus service is ON."
	else
		## if Pegasus is off, $isPegasusStop is 0
		isPegasusSysStatus=0

		echo "Pegasus service is OFF."
	fi
}

### enhancement and fixed
Shutdown_Pegasus() {

    # This is the exception only happens in ESX U1. Before install Hp-OpenIPMI, the service pegasus and service ipmi should be stopped.     
    if [ $FOUND_IPMI -ne 0 ];then
    
		verify_PegasusStatus
		
		## if Pegasus is off, then skip shutdown Pegasus and IPMI 
		if [ $isPegasusSysStatus -ne 0 ]; then
		
			echo -en "\nThe installer must now shut down the Pegasus CIM server in" | tee -a $LOGFILENAME
			echo -en "\norder to manipulate the IPMI driver. Pegasus CIM will be started" | tee -a $LOGFILENAME
			echo -en "\nagain once $1 is complete. Remote management services" | tee -a $LOGFILENAME
			echo -en "\nwhich depend on CIM will be unavailable during the shutdown" | tee -a $LOGFILENAME
			echo -en "\nperiod.\n" | tee -a $LOGFILENAME

			if [ ! $SILENT ]
			then
				verify_action "shut down Pegasus CIM in order to manipulate"
			fi
			## If this is in Silent installation, Pegasus CIM would be shutdown without requesting action.
			
			service pegasus stop
			isPegasusStop=1
			echo "Service pegasus is stopped." | tee -a $LOGFILENAME
			
			service ipmi stop
			echo "Service ipmi is stopped." | tee -a $LOGFILENAME
		fi
	fi
}

### enhancement and fixed
Start_Pegasus() {

	if [ $isPegasusStop -ne 0 ];then
		service pegasus start
		isPegasusStop=0
	    echo -en "\nService Pegasus is started." | tee -a $LOGFILENAME
	fi
}

### enhancement and fixed
Start_IPMI() {


     # If we don't check for Pegasus, then we should do nothing here
     # since we didn't need to stop the ipmi device

     if [ $fEnablePegasusCheck -eq 0 ]; then
             return
     fi

	# After uninstall Hp-OpenIPMI, the service ipmi should be started.
     
	if [ $FOUND_IPMI -ne 0 ] ; then
		service ipmi start		
	    echo -e "Service ipmi is started." | tee -a $LOGFILENAME
	fi
}

install() {

	splash
	
	[[ ! $SILENT ]] && verify_action "install"
	echo "" | tee -a $LOGFILENAME
	
	verify_esx_version
	echo "" | tee -a $LOGFILENAME
	
	verify_pkgs
	echo "" | tee -a $LOGFILENAME

	check_installed_pkgs
	echo "" | tee -a $LOGFILENAME

	### enhancement and fixed
	Shutdown_Pegasus "install"


	#
	# Silence the endless "ucd-snmp: Connection from 127.0.0.1" messages
	#
    if ( ! grep -q "^[ ]*snmpd: 127.0.0.1: severity debug" /etc/hosts.allow )
    then
            echo "snmpd: 127.0.0.1: severity debug" >> /etc/hosts.allow
            echo "Added the line \"snmpd: 127.0.0.1: severity debug\" to the file /etc/hosts.allow" >> $LOGFILENAME
	echo "" | tee -a $LOGFILENAME
    fi
	
	
	#The following agents will be started immediately after its installation
	[ ! $SILENT ] &&  export CMANOSTARTINSTALL="hpasmd"

    
	install_packages "Installing HP System Management Homepage" $SMH_PKGLIST






	[ $SILENT ] && configure_hpsmh 
	

	# Stop the Agents before installing hp-OpenIPMI package otherwise it will fail to install hp-OpenIPMI package
	#	check_installed $ASMSVC
	#	if [ $FOUND_IPMI -ne 0 ] && [ $INSTALLEDPKGS ]
	#	then
	#		stop_agents
	#		echo "" | tee -a $LOGFILENAME
	#		check_installed $HPIPMIPKG
	#		if [ $INSTALLEDPKGS ]
	#               then
	#                        local pkg=`rpm -qp $HP_OPENIPMI_PACKAGE`
	#                        if ( ! grep -q $INSTALLEDPKGS $HP_OPENIPMI_PACKAGE ) && ( ! ( rpm -Uvh --test --nodeps $HP_OPENIPMI_PACKAGE 2>&1 | grep -q "package $INSTALLEDPKGS (which is newer than $pkg) is already installed" ) )
	#                        then
	#                                remove_packages "Removing hp-OpenIPMI Stack" $HPIPMIPKG
	#                                echo "" | tee -a $LOGFILENAME
	#                        fi
	#                fi
	#	fi
	#
	
	install_packages "Installing HP Management Agents" $AGENT_PKGLIST
	echo "" | tee -a $LOGFILENAME
    
	# Configure the ESX Firewall
	if [ ! $SILENT ]
	then
	# Prompt the user to enable/disable the port for hpim service in the firewall if it has already been enabled
		if ( ! esxcfg-firewall -q | grep -q hpim )
		then
			echo -e "\nFor accessing the System Managament Homepage, the port for hpim service (2381)" | tee -a $LOGFILENAME
			echo -e "should be enabled in the firewall. " | tee -a $LOGFILENAME
			echo -n "Do you want to enable this port? <y/n> (default is y) " | tee -a $LOGFILENAME
	        read choice
            echo "$choice" >> $LOGFILENAME
            if [ "$choice" != "n" ] ; then
                    echo -n "Enabling port for hpim service (2381) in the firewall" | tee -a $LOGFILENAME
                `esxcfg-firewall -o 2381,tcp,in,hpim >> $LOGFILENAME 2>&1`
                if [ $? -eq 0 ] ; then
                            setsuccess
	            else
                            setfailure
               	fi
            else
                    `esxcfg-firewall -c 2381,tcp,in > /dev/null 2>&1`
            fi
		fi

	#
	# Prompt the user to enable/disable the port for HP System Insight Manager in the firewall 
	# if it has already been enabled
	#
		if ( ! esxcfg-firewall -q | grep -q hp-sim )
		then
			echo -e "\nFor allowing discovery by HP System Insight Manager, the port (2301)" | tee -a $LOGFILENAME
			echo -e "should be enabled in the firewall. " | tee -a $LOGFILENAME
			echo -n "Do you want to enable this port? <y/n> (default is y) " | tee -a $LOGFILENAME
	        read choice
            echo "$choice" >> $LOGFILENAME
            if [ "$choice" != "n" ] ; then
                echo -n "Enabling port for HP System Insight Manager (2301) in the firewall" | tee -a $LOGFILENAME
                `esxcfg-firewall -o 2301,tcp,in,hp-sim >> $LOGFILENAME 2>&1`
                if [ $? -eq 0 ] ; then
                
                    setsuccess
                    
                    if ( ! esxcfg-firewall -q | grep -q hpim )
                    then
						$SETCOLOR_WARNING
						echo -e "\nWARNING: Port 2381 is not enabled in the firewall" | tee -a $LOGFILENAME
						echo -e "         Port 2381 will now be attempted to be enabled " | tee -a $LOGFILENAME
						echo -e "         due to port 2301 has been enabled." | tee -a $LOGFILENAME
						echo -e "         Both port 2301 and 2381 are required by " | tee -a $LOGFILENAME
						echo -e "         HP System Insight Manager\n" | tee -a $LOGFILENAME
						$SETCOLOR_NORMAL

                        echo -n "Enabling port for hpim service (2381) in the firewall" | tee -a $LOGFILENAME
				        `esxcfg-firewall -o 2381,tcp,in,hpim >> $LOGFILENAME 2>&1`	
				        if [ $? -eq 0 ]; then 
							setsuccess
						else
							set failure
						fi							
						
                    fi
                            
	            else
                    setfailure
               	fi
            else
                `esxcfg-firewall -c 2381,tcp,in > /dev/null 2>&1`
            fi
		fi
		
	# Prompt the user to enable/disable the snmpd service in the firewall
		if ( ! esxcfg-firewall -q snmpd > /dev/null 2>&1 )
		then
			echo -e "\nFor the Insight Manager agents to communicate properly with HP Systems Insight" | tee -a $LOGFILENAME
			echo -e "\nManager, the snmpd service should be enabled in the firewall." | tee -a $LOGFILENAME
			echo -en "\nDo you want to enable the snmpd service? <y/n> (default is y) " | tee -a $LOGFILENAME
			read choice
			echo "$choice" >> $LOGFILENAME
			if [ "$choice" != "n" ] ; then
				echo -n "Enabling snmpd service in the firewall" | tee -a $LOGFILENAME
				`esxcfg-firewall --enableservice snmpd >> $LOGFILENAME 2>&1`
				if [ $? -eq 0 ] ; then
               			setsuccess
				else
						setfailure
				fi
			else
               	`esxcfg-firewall --disableservice snmpd > /dev/null 2>&1`
			fi
		fi
	# Prompt the user to enable/disable the port 280 that is used for adding the SIM certificate in SMH
        if ( ! esxcfg-firewall -q | grep -q sim-cert )
        then
            echo -en "\nFor adding the HP Systems Insight Manager Certificate in SMH, the port [280] \nshould be enabled in the firewall. \nDo you want to enable this port? <y/n> (default is y) " | tee -a $LOGFILENAME
            read choice
            echo "$choice" >> $LOGFILENAME
            if [ "$choice" != "n" ] ; then
                echo -n "Enabling port for SIM Certificate in SMH [280] in the firewall" | tee -a $LOGFILENAME
                `esxcfg-firewall -o 280,tcp,out,sim-cert >> $LOGFILENAME 2>&1`
                if [ $? -eq 0 ] ; then
                        setsuccess
                else
                        setfailure
                fi
            else
                    `esxcfg-firewall -c 280,tcp,out > /dev/null 2>&1`
            fi
        fi
            
    #
    # Else -  execute the silent installation of         
            
    else
        if [ "$ENABLEHPIMPORT" != "N" ] ; then
                echo -n "Enabling port for hpim service (2381) in the firewall" | tee -a $LOGFILENAME
                `esxcfg-firewall -o 2381,tcp,in,hpim >> $LOGFILENAME 2>&1`
                if [ $? -eq 0 ] ; then
                        setsuccess
                else
                        setfailure
                fi
        else
                `esxcfg-firewall -c 2381,tcp,in > /dev/null 2>&1`
        fi
        
        if [ "$ENABLEHP_SIMPORT" != "N" ] ; then
            echo -n "Enabling port for HP System Managment (2301) in the firewall" | tee -a $LOGFILENAME
            `esxcfg-firewall -o 2301,tcp,in,hp-sim >> $LOGFILENAME 2>&1`
            if [ $? -eq 0 ] ; then
                    setsuccess
            else
                    setfailure
            fi
		else
			`esxcfg-firewall -c 2301,tcp,in > /dev/null 2>&1`
		fi
       
        
        if [ "$ENABLESNMPSERVICE" != "N" ] ; then
                echo -n "Enabling snmpd service in the firewall" | tee -a $LOGFILENAME
                `esxcfg-firewall --enableservice snmpd >> $LOGFILENAME 2>&1`
                if [ $? -eq 0 ] ; then
                        setsuccess
                else
                        setfailure
                fi
        else
                `esxcfg-firewall --disableservice snmpd > /dev/null 2>&1`
        fi
        
		if [ "$ENABLESIMCERTPORT" != "N" ] ; then
			echo -n "Enabling port [280] for adding the HP SIM Certificate in SMH" | tee -a $LOGFILENAME
			`esxcfg-firewall -o 280,tcp,out,sim-cert >> $LOGFILENAME 2>&1`
			if [ $? -eq 0 ] ; then
					setsuccess
			else
					setfailure
			fi
        else
                `esxcfg-firewall -c 280,tcp,out > /dev/null 2>&1`
        fi
    fi
    echo "" | tee -a $LOGFILENAME
    
	[[ ! $SILENT ]] && configure_hpasm
	echo "" | tee -a $LOGFILENAME
	
	stop_agents
    echo "" | tee -a $LOGFILENAME
    stop_smh
    echo "" | tee -a $LOGFILENAME
    stop_snmp
    echo "" | tee -a $LOGFILENAME
        

	 # Insert a 3 sec delay before starting the services
	 sleep 3
	 
    start_snmp
    echo "" | tee -a $LOGFILENAME
    

	 #	### enhancement and fixed
	 #	Start_Pegasus
	 #	echo "" | tee -a $LOGFILENAME


    svc_control "Starting System Management Homepage" start $SMHSVC
    echo "" | tee -a $LOGFILENAME
    svc_control "Starting HP Insight Manager agents" start $ASMSVC
    echo "" | tee -a $LOGFILENAME

	### enhancement and fixed
	Start_Pegasus
	echo "" | tee -a $LOGFILENAME

    post_splash install
        
}

uninstall() {

	splash
	
	verify_action "remove"
	echo "" | tee -a $LOGFILENAME
	
	verify_esx_version
	echo "" | tee -a $LOGFILENAME
	
    ### enhancement and fixed
	Shutdown_Pegasus "uninstall"
	
	
	stop_agents
	echo "" | tee -a $LOGFILENAME
	stop_smh
	echo "" | tee -a $LOGFILENAME
	stop_snmp
	echo "" | tee -a $LOGFILENAME
	remove_packages "Removing HP Insight Manager agents" $AGENTLIST
	echo "" | tee -a $LOGFILENAME
	remove_packages "Removing HP System Management Homepage" $SMHLIST
	echo "" | tee -a $LOGFILENAME
	
    # Disable the port for hpim in the firewall if it had been enabled
	if ( esxcfg-firewall -q | grep -q hpim )
	then
		echo -n "Disabling port for hpim service (2381) in the firewall" | tee -a $LOGFILENAME
        	if ( esxcfg-firewall -c 2381,tcp,in > /dev/null 2>&1 )
		then
	        setsuccess
		else
			setfailure
		fi
	fi
	
    # Disable the port for hpim in the firewall if it had been enabled
	if ( esxcfg-firewall -q | grep -q hp-sim )
	then
		echo -n "Disabling port for HP System Insight Manager (2301) in the firewall" | tee -a $LOGFILENAME
        	if ( esxcfg-firewall -c 2301,tcp,in > /dev/null 2>&1 )
		then
	        setsuccess
		else
			setfailure
		fi
	fi
	
	
	if ( esxcfg-firewall -q | grep -q sim-cert )
    then
        echo -en "Disabling port for the SIM Certificate in SHM [280] in the firewall" | tee -a $LOGFILENAME
        
        if ( esxcfg-firewall -c 280,tcp,out > /dev/null 2>&1 )
        then
                setsuccess
        else
                setfailure
        fi
    fi
	
	
	if ( esxcfg-firewall -q snmpd | grep -q "enabled" )
	then
			$SETCOLOR_WARNING
        	echo -e "\nWARNING: snmpd service has been enabled in the firewall." | tee -a $LOGFILENAME
			echo -e "Disable this service using the command  " | tee -a $LOGFILENAME
			echo -e "  \"esxcfg-firewall --disableservice snmpd\" " | tee -a $LOGFILENAME
			echo -e "if no other program is using it" | tee -a $LOGFILENAME
			$SETCOLOR_NORMAL
	fi

        
        
    ### enhancement and fixed
    Start_IPMI
     
    ### enhancement and fixed    
    Start_Pegasus
     

	post_splash uninstall
}

usage() {
	splash
	echo "Usage:"
	echo ""
	echo "${0} {--install|--uninstall|--silent} [--inputfile filename]"
	echo ""
	echo -e "--install:"
	echo -e "\tThis will attempt to install version ${VERSION_NAME}${MINOR_VERSION} of the HP Insight"
	echo -e "\tManager Agents. Uninstall the previous versions of agents"
	echo -e "\tbefore installing version ${VERSION_NAME}."
	echo ""
	echo -e "--uninstall:"
	echo -e "\tThis will attempt to uninstall the HP Insight Manager Agents"
	echo -e "\tfrom your system. You must be running versions 6.40 or later."

	echo -e "\tVersions prior to 6.40 must be uninstalled manually."
	echo ""
	echo -e "--silent"
    echo -e "\tThis will attempt a silent installation of the HP Insight"
    echo -e "\tManager Agents. Uninstall the previous versions of agents"
	echo -e "\tbefore installing version ${VERSION_NAME}. This option also requires"
	echo -e "\tthe '--inputfile' option where filename points to the"
	echo -e "\tconfiguration file that contains your settings."
	echo -e "\tPlease see the README and the hpmgmt.conf.example files"
	echo -e "\tfor more details."
	
    do_exit 20

}

# START MAIN
verify_root

echo -e "\n**********`date`**********\n" >> $LOGFILENAME
if [ $FOUND_IPMI -ne 0 ]; then
	echo "The system has an HP PCI IPMI device" >>  $LOGFILENAME
	## echo "The ESX version is: build -" $ESX_BUILD_VERSION | tee -a $LOGFILENAME
fi

# --- DO NOT EXECUTE THIS FUNCTION FOR NOW
# NOTE: We need a better soluton for when to turn Pegasus on and off
#
# determine_pegasus_check
#

case "$1" in
	--silent)
	SILENT=1
	if [ "$2" != "--inputfile" ] ; then
                usage
        elif [ ! -e "$3" ]; then
                echo $3
                echo "Input file does not exist!" | tee -a $LOGFILENAME
                do_exit 20;
	elif [ "$4" != "" ]; then
		usage
        else
		. $3
	fi

	install
	;;
	--install)
	if [ "$2" != "" ]; then
        	usage
	else
		install
	fi
	;;
	--uninstall)
	if [ "$2" != "" ]; then
        	usage
        else
		uninstall
	fi
	;;
	*)
	usage
	;;
esac

exit 0

