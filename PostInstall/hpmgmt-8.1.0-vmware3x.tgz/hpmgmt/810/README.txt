

*******************************************************************************
**                 ***************** README *****************                **
*******************************************************************************

The files contained in the HP Advanced Server Management Package for VMware
ESX Server provides the user with multiple system management. The standard 
configuration would be to use the HP Systems Insight Manager (HP SIM)
software. For more information on HP SIM, see: 

http://h18013.www1.hp.com/products/servers/management/hpsim/index.html


KNOWN ISSUES:
===============================================================================

 1. The link to storage controllers that do not have any disk drives 
    attached might not be displayed in the System Management Homepage.


 2. The HP Management Agents retrieve the Processor Utilization information 
    for only Processor 0, even on a multi-processor system. 


 3. During the configuration of System Management Homepage using 
    "hpSMHSetup.pl", the Import Option is disabled in the Trusted 
    Certificates screen.


 4. If you access the SAN Storage System in System Management Homepage
    through the Storage System link under External Storage Connections and 
    try to refresh it by clicking on the link 
    "Home->Storage->{Storage System Name}" in the navigation bar, it will
    show a blank page.


 5. After installation of the Insight Management Agents, 
    /var/spool/compaq/cma.log file might show the following error
    messages:

    "Shutting down SAS agent (cmasasd): Failed to open Registry"
    "cmahealthd[13664]: ERROR: Failed to open /dev/cpqhealth/crom"
    "cmahealthd[13664]: CheckForResMemChange:  IOCTL ERROR 0xffffffff"
    "sh: line 1: /bin/mail: No such file or directory"

    These error messages do not affect the functionality of the agents 
    and can safely be ignored. 

 6. The System Management Homepage may display the DIMM information 
    incorrectly after a memory board containing the DIMMs is hot-added on 
    a DL580 G3 or ML570 G3.


 7. The UID ON/OFF buttons may be displayed in System Management 
    Homepage even when the UID is in the blinking state (while accessing 
    the iLO remote console) on servers having iLO.

 8. The iLO2 reset message may not be displayed in the service console for
    DL580 G4 and ML570 G4 servers.

 9. After installation of the Insight Management Agents, 
    /var/spool/compaq/cma.log file might show the following error messages: 

    Sep 10 01:25:11 DL580-301GA cmaperfd[1537]: 
    cmaperfd: Receive failed:Identifier removed  (PEER3004)    
    Sep 10 01:25:11 DL580-301GA cmaided[1629]: 
    cmaided: Receive failed:Identifier removed  (PEER3004)    
    Sep 10 01:25:11 DL580-301GA cmafcad[1631]: 
    cmafcad: Receive failed:Identifier removed  (PEER3004)    
    Sep 10 01:25:11 DL580-301GA cmastdeqd[1535]: 
    cmastdeqd: Receive failed:Identifier removed  (PEER3004)    
    Sep 10 01:25:11 DL580-301GA cmahealthd[1548]: 
    cmahealthd: Receive failed:Identifier removed  (PEER3004)    
    Sep 10 01:25:11 DL580-301GA cmascsid[1674]: 
    cmascsid: Receive failed:Identifier removed  (PEER3004)   
    Sep 10 01:25:11 DL580-301GA cmasasd[1683]: 
    cmasasd: Receive failed:Identifier removed  (PEER3004)    
    Sep 10 01:25:11 DL580-301GA cmapeerd[3654]: 
    Started hp Advanced Server Management Agents Peer Manager

    These error messages do not affect the functionality of the agents 
    and can safely be ignored.


10. After installation of the Insight Management Agents, 
    /var/spool/compaq/cma.log file might show the following error message: 

    Jan 17 07:43:09 DL380G5-3 cmapeerd[6042]: do_snmp_trap: snmp_send() call failed.

    These error messages do not affect the functionality of the agents and can
    safely be ignored.

11. The value "N/A" is seen for Base I/O Address on the NIC SMH Page for the
    Broadcom NICs. 

12. SMH service is not responding after a fiber channel cable is removed from its
    connection to an Emulex HBA. It has also been observed that failed messages and 
    incorrect status may be reported when "service hpasm stop" is executed after
    the fiber channel cable is removed in this situation.

13. Fan status is incorrectly displayed as "Degraded" when a fan is removed. 
    The expected status displayed should be "Unknown".

14. Processor Utilization Box in the SMH may get Degraded or Failed when switching 
    back and forth between the Utilization & Process Utilization links. This will 
    occur only when threshold values are saved for the given interval in the 
    System Management Homepage and maybe encountered even before Process Utilization 
    passes the threshold value.

15. For Emulex LPe11000 connected to MSA1000, the Port number/name may not be 
    displayed for Physical drives present in the SMH.

16. When the critical value threshold is passed, the value on the bar graph
    and the value in the CRITCIAL box may not be correct on the SMH page 
    ( Utilization -> Processor Utilization). The status of the processor 
    utilization is reported as FAILED which is correct since the threshold has
    been passed; however, the bar graph might not show the value past the 
    critical threshold.

17. The System Management Homepage may time out when multiple virtual machines are 
    cloned at the same time. The System Management Homepage becomes available when 
    the cloning is completed.
 



INSTALLATION INSTRUCTIONS:
============================================================================

IMPORTANT: 
With v8.0.0 release and later, the HP Insight Manager Agents support only 
ESX 3.0.1 and later.

The upgrade of HP Insight Manager Agents is not supported. Please uninstall 
the older versions of agents before installing the Insight Manager Agents.

Note that you must always be logged on as a user having administrator
privileges for all of the instructions in this document.

Once the VMware ESX Server system has been installed and configured, log onto 
the console operating system. Change the working directory to the directory 
where this file was unbundled (e.g. /home/vmware/hpmgmt). The installation 
script will perform some basic checks and will then guide you through the 
installation process.

On ESX 3.x:
-------------
You must enable the firewall port for the `hpim' service (2381) for accessing 
the System Management Homepage. The `snmpd' service should be enabled in the 
firewall for the Insight Manager agents to communicate properly with the HP
Systems Insight Manager. Port 280 should be enabled in the firewall for 
adding the HP Systems Insight Manager certificate in SMH. These ports can be 
enabled by using the "esxcfg-firewall" command in the service console, or by 
answering 'y' when prompted by the installation script.

Note:
For adding the HP Systems Insight Manager (HPSIM) certificate in SMH, in
addition to opening the port 280 in the firewall, the DNS name of HPSIM Server
should be specified in the /etc/hosts file of ESX host.

For allowing discovery by HP Systems Insight Manager (HPSIM), the port 2301
should be enabled in the firewall.

These ports (280 and 2301) can be enabled by using the "esxcfg-firewall" 
command in the service console, or by answering 'y' when prompted by the
installation script.


Some things you will want to consider before you start the installation:

 1. Will you be using the HP SIM console?
 
    If so, you want to allocate  an IP address for the HP SIM console as you 
    will need to provide it during the installation process. You must provide
    either the IP address or the fully qualified DNS name for the HP SIM 
    console. 
    This will be an additional "rocommunity" string in the snmpd.conf 
    file. The installation script will ask for this information or you 
    can skip this step and modify "/etc/snmp/snmpd.conf" to the
    necessary information.

 2. Do you have other ProLiant or HP servers that you wish to manage? 

    If so, you should layout what the SNMP community strings should be. The
    default is usually "public" but since everybody knows the default, this
    is not considered to be very secure. The snmpd.conf(5) man page has
    more information. In general, you need to know the "community strings"
    (e.g. public) and the IP address of the HP SIM console.

Once you have the information to configure the SNMP and web enabled agent
interfaces, you can install the packages. 

To install, you must be logged onto the console OS as a user having 
administrator privileges. At the command prompt, enter:

    [root@myserver 810] ./installvm810.sh

You will be presented with the various installation options.


During an install, a prompt appears when the following two conditions 
exist:
 
  (1) the system has an HP PCI IPMI device and
  (2) the Pegasus service is in use 

  The prompt will request to stop Pegasus service.


"  The installer must now shut down the Pegasus CIM server in
   order to manipulate the IPMI driver. Pegasus CIM will be started
   again once install is complete. Remote management services
   which depend on Pegasus CIM will be unavailable during the shutdown
   period.

   This script will now attempt to shut down Pegasus CIM in order to 
   manipulate the HP Insight Manager Agents. Do you wish to continue (y/n)"

When the user's answer is yes, the Pegasus service will be stopped and 
installation process would be continued. After installation, the 
Pegasus service would be started again.


When the user's answer is no, the installation script will stop since the user
has indicated they do not wish to continue.



Automating the Installation:

To automate the installation of the agents, make a copy of the 
hpmgmt.conf.example file and rename it to hpmgmt.conf. This file contains
the configuration information for the hpasm package and firewall port 
configurations (for ESX 3.x). Edit this file to fit your environment. 
Please see the example file for complete details on the configuration 
settings. At a minimum, you should configure Local Read/Write community 
for snmp agent. When you are ready to install, run the script as follows:

[root@myserver 810] ./installvm810.sh --silent --inputfile hpmgmt.conf

This will start the installation process immediately--you will not be
prompted for confirmation. If you are missing information from your
configuration file, you may be prompted for it during installation.

To automate the configuration of the System Management Homepage, place
a copy of the smhpd.xml file with the desired settings into the same 
directory as the installvm810.sh script. When performing a silent install
this file will be copied to the appropriate directory. It is recommended
to use a file from a pre-existing installation rather than edit by hand.


VALIDATING INSTALLATION: 
============================================================================

You can run a few utilities to validate that the installation of the
package was successful:

snmpwalk -v 1 localhost -c public enterprises | grep hp

       This command will list all the SNMP Management Information Block 
       (MIB) items associated with "hp". These are the HP management items.

snmpwalk -v 1 localhost -c public enterprises | grep 6876

       This command will list all the SNMP Management Information Block (MIB)
       items associated with the VMware ESX Server software. These are the 
       VMware management items. Note that once the system is rebooted, this
       command may no longer work if you have not enabled the VMware SNMP
       subagent to run at startup (automatic). If you want full monitoring
       of the system, you need to log onto the VMware console as previously
       described and enable automatic start of the VMware SNMP processes.

https://fully.qualified.name.com:2381

       Point your web browser to the fully qualified name of this server (or
       the IP address) and port 2381. Note that you MUST use the "https://"
       prefix and port ":2381" or this will not work. This will allow you
       to log into the Web Agent and view the status of the machine. The
       System Management Homepage uses OS accounts for authentication.


REMOVAL INSTRUCTIONS:
============================================================================

You need to change to the directory where the installvm810.sh script is 
located. Then enter the following command:

    [root@myserver 810] ./installvm810.sh --uninstall 

This will remove all instances of the HP Advanced Management Software 
except the snmp stack.

During the uninstall, a prompt appears when the following 
conditions exist: 

  (1) the system has an HP PCI IPMI device and
  (2) the Pegasus service is in use

  The prompt will request to stop Pegasus service.

"  The installer must now shut down the Pegasus CIM server in
   order to manipulate the IPMI driver. Pegasus CIM will be started
   again once uninstall is complete. Remote management services
   which depend on Pegasus CIM will be unavailable during the shutdown
   period.

   This script will now attempt to shut down Pegasus CIM in order to 
   manipulate the HP Insight Manager Agents. Do you wish to continue (y/n)"

When the user's answer is yes, the Pegasus service will be stopped and the
uninstall process will be continued. After uninstall of the agents, the 
Pegasus service will be started again.

When the user's answer is no, the installation script will stop since the user
has indicated they do not wish to continue.


The firewall port for the `hpim' service, port 280, and port 2301 will be 
disabled during uninstall of the agents. 

A warning is displayed in regards to the snmpd service that has been enabled
in the firewall. The `snmpd' service can be disabled in the firewall 
by using the command "esxcfg-firewall --disableservice snmpd".

AGENT CONFIGURATION:
============================================================================

For the storage agents to display the correct information for the Qlogic and 
Emulex HBAs, the libraries corresponding to the Qlogic and Emulex driver 
versions have to be installed on the ESX Service Console.

Please ensure that you run through these instructions ONLY if you do not see 
a link for either the HBA or the target drives in the System Management 
Homepage.

The following steps guide you through the installation for the corresponding 
libraries:


 1.  Find the HBA driver version number. (See Additional notes below)

 2.  Download the libraries for the driver loaded in the vmkernel from the 
     following links:
     (see additional notes below to determine which driver has been loaded 
     in the vmkernel)

     Link for Emulex libraries:  
          http://www.emulex.com/vmware/support/index.jsp 

     Link for Qlogic libraries: 
          http://support.qlogic.com/support/oem_product_detail_vmware.asp

     NOTE: The Emulex files that need to be downloaded are the Core Library 
           and the HP Rubah library files.

 3.  Stop the 'hpsmhd' and 'hpasm' agents by issuing the commands from the 
     service console,

         'service hpsmhd stop' and 'service hpasm stop' 

     NOTE: you must be logged in as a user having administrative privileges.

 4.  Install the libraries which were downloaded in step 1 using the install 
     script present in those packages.

     For the Emulex libraries, please copy the HP Rubah library file 
     to /usr/lib directory on the ESX host 
     (i.e., Copy the file libemsdm.so into /usr/lib directory).

 5.  For the Qlogic libraries you must rename the library file. 
     Use the following command to rename the library file: 

        'mv /usr/lib/libqlsdm-ia32.so /usr/lib/libqlsdm.so'

 6.  First start the 'hpsmhd' service using the command 'service hpsmhd start'.

 7.  Then, start the 'hpasm' service using the command 'service hpasm start'.


 Additional notes:

 To find the version number of the HBA driver that is being using in the 
 ESX system, the information can be found in /proc/vmware/version.

 Here is an example of QLogic and Emulex entries in the version file:

 QLogic:    qla2300_707                    build 96281: 7.07.04.01.3vmw
 Emulex:    lpfcdd_732                     build 96281: 7.3.2_vmw10




ACKNOWLEDGEMENTS:
============================================================================

This package contains additional 3rd-party software. By installing this
software you agree to the licensing terms for use of this software set forth
in the LICENSE file.


Copyright (c) 2008  Hewlett-Packard  Development  Company, L.P.
