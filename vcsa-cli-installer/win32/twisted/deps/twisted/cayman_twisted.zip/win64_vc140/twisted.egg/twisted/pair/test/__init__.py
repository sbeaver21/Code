'pair tests'
