"""
Finger example application.
"""
